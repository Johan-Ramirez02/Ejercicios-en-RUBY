puts "Introduzca 3 números enteros, definiremos el mayor de los 3 numeros"
numero1 = ARGV[0].to_i
numero2 = ARGV[1].to_i
numero3 = ARGV[2].to_i
    #Condiciones para definir el mayor
if (numero1 > numero2) && (numero1 > numero3)
    puts "Este número #{mayor} es mayor"
elsif numero2 > numero1 && numero2 > numero3
    puts "Este número #{numero2} es mayor"
elsif  numero3 > numero1 && numero3 > numero2
    puts "Este número #{numero3} es mayor"
else  puts "hay 2 o más números iguales"
end

