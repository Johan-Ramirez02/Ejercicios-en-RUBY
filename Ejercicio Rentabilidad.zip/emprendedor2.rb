puts "Ingrese precio"
precio = ARGV[0].to_i
puts "ingrese catidad de clientes regular"
usuario_regular = ARGV[1].to_i
puts "ingrese catidad de clientes premium"
usuario_premium = ARGV[2].to_i
puts "ingrese catidad de clientes free"
usuario_free = ARGV[3].to_i
premium = precio*usuario_premium*2
regular = precio*usuario_regular
free = precio*usuario_free*0
puts "ganancia cliente premium #{regular} dolares"
puts "ganancia cliente premium #{premium} dolares"
puts "ganancia cliente premium #{free} dolares"
puts "Ingrese gastos de inversión"
gastos = ARGV[4 ].to_i
utilidades_brutas = premium+regular+free
utilidades_netas = utilidades_brutas-gastos
puts "Ganancias liquidas #{utilidades_netas} dolares"


