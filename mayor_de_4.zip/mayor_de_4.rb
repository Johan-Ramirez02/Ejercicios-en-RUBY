puts "introduzca números"
num1 = ARGV[0].to_i
num2 = ARGV[1].to_i
num3 = ARGV[2].to_i
num4 = ARGV[3].to_i
if num1 > num2 && num1 > num3 && num1 > num4
    puts "Número mayor es #{num1}"
    elsif num2 > num1 && num2 > num3 && num2 > num4
    puts "Número mayor es #{num2}"
    elsif num3 > num1 && num3 > num2 && num3 > num4
    puts "Número mayor es #{num3}"
    # Si algún numero es vacio
    elsif num4 == false || num4 > num1 && num4 > num2 && num4 > num3
    puts "Número mayor es #{num4}"  
end


