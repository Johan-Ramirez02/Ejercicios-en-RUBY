gravedad = ARGV[0].to_i
radio = ARGV[1].to_i
escape = Math.sqrt(2*gravedad*radio)
puts "La velocidad de escape es de #{escape} de velocidad"